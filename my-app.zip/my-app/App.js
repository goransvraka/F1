import React from "react";
import {
    Route,
    NavLink,
    Router
} from "react-router-dom";
import history from './history';
import Drivers from './Drivers';
import Teams from './Teams';
import Races from './Races';
import Driverdetails from './Driverdetails';
import Teamlink from "./Teamlink";
import GrandPrix from "./GrandPrix";
import './index.css';
import logo from './formula-1.png';
import nav1 from './helmet.png';
import nav2 from './teams.png';
import nav3 from './races.png';



class App extends React.Component {

    render() {
        const routes = [
            {
                path: "/",
                exact: true,
                header: () => <button className="btn_blue">Drivers</button>,
            },
            {
                path: "/Teams",
                header: () => <button className="btn_blue">Teams</button>,
            },
            {
                path: "/Races",
                header: () => <button className="btn_blue">Races</button>,
            },
            {
                path: "/Teamlink",
                header: () => <div className="d-inline"><button className="btn">Teams</button><button className="btn_blue">Teamlink</button></div>,
            },
            {
                path: "/Driverdetails",
                header: () => <div className="d-inline"><button className="btn">Driver</button><button className="btn_blue">Driver details</button></div>,
            },
            {
                path: "/GrandPrix",
                header: () => <div className="d-inline"><button className="btn">Races</button><button className="btn_blue">Grand Prix</button></div>,
            },/**/
        ];
        return (

            <Router history={history}>
                <div></div>
                <div className="container-fluid no-gutters">
                    <div className="row">
                        <div className="col-2 no-gutters">
                            <div className="navigation">
                                <img className="logo" src={logo} alt="Formula logo" />
                                <div className="vertical-menu">
                                    <NavLink exact to="/"><img src={nav1} alt="Drivers" />Drivers</NavLink>
                                    <NavLink to="/Teams"><img src={nav2} alt="Teams" />Teams</NavLink>
                                    <NavLink to="/Races"><img src={nav3} alt="Races" />Races</NavLink>
                                </div>
                            </div>
                        </div>

                        <div className="col no-gutters">
                            <div className="row header no-gutters">
                                <div className="col-8">
                                    <NavLink to="/"><button className="btn"><i className="fa fa-home"></i>  F-1 Feeder</button></NavLink>
                                    <div className="d-inline">
                                        {routes.map((route, index) => (
                                            <Route
                                                key={index}
                                                path={route.path}
                                                exact={route.exact}
                                                component={route.header}
                                            />
                                        ))}
                                    </div>
                                </div>
                                <div className="col-4">
                                    <input className="search" type="text" placeholder=" Search ..."></input>
                                    <i className="btn_search fa fa-search"></i>
                                </div>
                            </div>
                            <div className="row no-gutters">
                                <div className="col">
                                    <Route exact path="/" component={Drivers} />
                                    <Route path="/Teams" component={Teams} />
                                    <Route path="/Races" component={Races} />
                                    <Route path="/Teamlink/:teamID" component={Teamlink} />
                                    <Route path="/Driverdetails/:driverID" component={Driverdetails} />
                                    <Route path="/GrandPrix" component={GrandPrix} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Router>
        );
    }
}

export default App;

