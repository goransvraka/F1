import React from 'react';
import DriversImagesList from './DriversImagesList.json';
import FlagImageList from './FlagImageList.json';
import DriverCountryImgUrl from './DriverCountryImgUrl.json';
import * as $ from 'jquery';
var driverID = "";



class Driverdetails extends React.Component {

    constructor() {

        super();

        this.state = {

            driver: [],
            driverResul: [],
            isLoading: true,
            driversImg: DriversImagesList,
            flagsImg: FlagImageList,
            countryImg: DriverCountryImgUrl
        }

        this.getAllData = this.getAllData.bind(this);
    }

    componentDidMount() {
        this.getAllData();
    }

    getAllData() {
        driverID = this.props.match.params.driverID
        var firstCall = $.ajax(`http://ergast.com/api/f1/2013/drivers/${driverID}/driverStandings.json`);
        var secondCall = $.ajax(`http://ergast.com/api/f1/2013/drivers/${driverID}/results.json`);
        $.when(firstCall, secondCall).done(function (data1, data2) {
            this.setState({
                driver: data1[0].MRData.StandingsTable.StandingsLists[0].DriverStandings,
                driverResul: data2[0].MRData.RaceTable.Races,
                isLoading: false
            });

        }.bind(this));
    }

    render() {
        if (this.state.isLoading) {
            return <h3>It is loading...</h3>;
        }

        let driverImgUrl = this.state.driversImg.filter(vozac => vozac.driverId === this.state.driver[0].Driver.driverId)
        let driverCountryImgUrl = this.state.countryImg.filter(drzava => drzava.driverId === this.state.driver[0].Driver.driverId)

        return (
            <div className="row centralni">
                <div className="col-3 teamlevi no-gutters">
                    <div className="teamlogo">
                        <div className="p-1">
                            <img src={driverImgUrl[0].url} alt="Team logo" width="100" height="100" />
                        </div>
                        <div className="p-1">
                            <img src={driverCountryImgUrl[0].url} alt="flag-country_code" />
                            <h4>{this.state.driver[0].Driver.givenName}</h4>
                            <h4>{this.state.driver[0].Driver.familyName}</h4>
                        </div>
                    </div>
                    <div className="teaminfo">
                        <p>Country: {this.state.driver[0].Driver.nationality}</p>
                        <p>Team: {this.state.driver[0].Constructors[0].name}</p>
                        <p>Birth: {this.state.driver[0].Driver.dateOfBirth}</p>
                        <p>Biography: <a href={this.state.driver[0].Driver.url} target="_blank" rel="noopener noreferrer"><i class="fa fa-external-link"></i></a></p>
                    </div>
                </div>
                <div className="col-9 teamdesni no-gutters">
                    <table>
                        <thead>
                            <tr><th colSpan="2">Formula 1 2013 Results</th><th></th><th></th><th></th></tr>
                        </thead>
                        <tbody>
                            <tr><td>Round</td><td>Grand Prix</td><td>Team</td><td>Grid</td><td>Race</td></tr>
                            {this.state.driverResul.map((driverResul, i) => { return <DriverResul key={i} data={driverResul} flagsImgProps={this.state.flagsImg} /> })}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }
}

class DriverResul extends React.Component {
    render() {
        let country = this.props.flagsImgProps.filter(country => country.raceName === this.props.data.raceName)[0]
        return (
            <tr><td>{this.props.data.round}</td>
                <td>
                    <img src={country.countryImgUrl} alt="flag-country_code" width="32" height="20" />
                    {this.props.data.raceName}
                </td>
                <td>{this.props.data.Results[0].Constructor.name}</td>
                <td>{this.props.data.Results[0].grid}</td>
                <td className={"mesto" + this.props.data.Results[0].position}>{this.props.data.Results[0].position}</td>
            </tr>
        );
    }
}


export default Driverdetails;