import React from 'react';
import * as $ from 'jquery';
import {
    Link,
} from "react-router-dom";
import history from './history';
import NationalityFlag from './NationalityFlag.json';


class Drivers extends React.Component {
    constructor() {
        super();

        this.state = {
            drivers: [],
            countryImg: NationalityFlag
        }
    }

    componentDidMount() {
        this.getDrivers();
    }

    getDrivers() {
        var url = "http://ergast.com/api/f1/2013/driverStandings.json";
        $.get(url, (data) => {
            this.setState({ drivers: data.MRData.StandingsTable.StandingsLists[0].DriverStandings });
        })
    }

    render() {
        return (
            <div className="main">
                <div className="naslov">Drivers Championship</div>
                <table className="tabela">
                    <thead className="theader">
                        <tr><th colSpan="2">Drivers Championship Standings - 2013</th><th></th><th></th></tr>
                    </thead>
                    <tbody>
                        {this.state.drivers.map((drivers, i) => { return <Driver key={i} data={drivers} flagsImgProps={this.state.countryImg} /> })}
                    </tbody>
                </table>

            </div>
        );
    }
}


class Driver extends React.Component {
    render() {
        let country = this.props.flagsImgProps.filter(country => country.nationality === this.props.data.Driver.nationality)[0]
        return (
            <tr><td>{this.props.data.position}</td>

                <td>
                    <Link onClick={() => history.push('/Driverdetails/' + this.props.data.Driver.driverId)}>
                        <img src={country.flagUrl} alt="flag-country_code" width="32" /> &nbsp;
                    {this.props.data.Driver.givenName} {this.props.data.Driver.familyName}</Link>
                </td>
                <td>{this.props.data.Constructors[0].name}</td>
                <td>{this.props.data.points}</td>
            </tr>
        );
    }
}
export default Drivers;