import React from 'react';
import * as $ from 'jquery';
//import parse from 'html-react-parser';
import './index.css';
//import Ispistabele from './Ispistabele';
import FlagImageList from "./FlagImageList.json";
import DriverCountryImgUrl from './DriverCountryImgUrl.json';

var raceID = "";

class Racedetails extends React.Component {
  constructor() {
    super();
    this.state = {
      race: [],
      raceResul: [],
      countryFlag: FlagImageList,
      flagsImg: DriverCountryImgUrl,
      isLoading: true
    }
  }

  componentDidMount() {
    this.getAllData();
  }

  getAllData() {
    raceID = this.props.match.params.raceID
    var firstCall = $.ajax(`http://ergast.com/api/f1/2013/1/qualifying.json`);
    var secondCall = $.ajax(`http://ergast.com/api/f1/2013/1/results.json`);
    $.when(firstCall, secondCall).done(function (data1, data2) {
      this.setState({
        race: data1[0].MRData.RaceTable.Races,
        raceResul: data2[0].MRData.RaceTable.Races,
        isLoading: false
      });
    }.bind(this));
  }
  render() {
    if (this.state.isLoading) {
      return <h3>It is loading...</h3>;
    }

    let raceCountryImgUrl = this.state.countryFlag.filter(drzava => drzava.raceName === this.state.race[0].raceName)
    console.log(this.state.raceResul);
    return (
      <div className="row centralni">

        <div className="col-2 teamlevi no-gutters">
          <div className="teamlogo">
            <div className="p-1">
              <img src={raceCountryImgUrl[0].countryImgUrl} alt="flag-country_code" />
            </div>
            <div className="p-1">
              {this.state.race[0].raceName}
            </div>
          </div>
          <div className="teaminfo">
            <p>Country: {this.state.race[0].Circuit.Location.country} </p>
            <p>Location: {this.state.race[0].Circuit.Location.locality}</p>
            <p>Date: {this.state.race[0].date}</p>
            <p>Full Report: <a href="www.wdasdaafa" target="_blank" rel="noopener noreferrer"><i class="fa fa-external-link"></i></a></p>
          </div>
        </div>

        <div className="col-5 teamdesni no-gutters">
          <table>
            <thead>
              <tr><th colSpan="2">Qualifying results</th><th></th><th></th><th></th></tr>
            </thead>
            <tbody>
              <tr><td>Pos</td><td>Driver</td><td>Team</td><td>Best Time</td></tr>

              {this.state.race[0].QualifyingResults.map((race, i) => { return <QualifyingResul key={i} data={race} raceResul={this.state.raceResul} flagsImgProps={this.state.flagsImg} /> })}

            </tbody>
          </table>
        </div>

        <div className="col-5 teamdesni no-gutters">
          <table>
            <thead>
              <tr><th colSpan="2">Race Results</th><th></th><th></th><th></th><th></th></tr>
            </thead>
            <tbody>
              <tr><td>Pos</td><td>Driver</td><td>Team</td><td>Results</td><td>Points</td></tr>
              {this.state.raceResul[0].Results.map((raceResul, i) => { return <RacesResul key={i} data={raceResul} race={this.state.race} flagsImgProps={this.state.flagsImg} /> })}
            </tbody>
          </table>
        </div>
      </div>

    );
  }
}

class RacesResul extends React.Component {

  render() {

    let country = this.props.flagsImgProps.filter(country => country.driverId === this.props.data.Driver.driverId)[0]
    let status1 = ""
    if (this.props.data.status === "Finished") {
      status1 = this.props.data.Time.time
    } else {
      status1 = this.props.data.status
    }
    console.log(status1)

    return (
      <tr>
        <td>{this.props.data.position}</td>
        <td>
          <img src={country.url} alt="flag-country_code" width="32" height="20" />
          {this.props.data.Driver.familyName}
        </td>
        <td>{this.props.data.Constructor.name}</td>
        <td>{status1}</td>
        <td className={"mesto" + this.props.data.position}>{this.props.data.points}</td>
      </tr>
    );
  }
}

class QualifyingResul extends React.Component {
  render() {

    var k = Date.parse("1543314832505");
    console.log(k)
    let country = this.props.flagsImgProps.filter(country => country.driverId === this.props.data.Driver.driverId)[0]
    return (
      <tr>
        <td>{this.props.data.position}</td>
        <td>
          <img src={country.url} alt="flag-country_code" width="32" height="20" />
          {this.props.data.Driver.familyName}
        </td>
        <td>{this.props.data.Constructor.name}</td>
        <td>{this.props.data.Q3}</td>
      </tr>
    );
  }
}

export default Racedetails;