import React from 'react';
import * as $ from 'jquery';
import TeamLogo from './TeamLogo.json';
import NationalityFlag from './NationalityFlag.json';
import FlagImageList from './FlagImageList.json';

var teamID = "";

class Teamlink extends React.Component {
    constructor() {
        super();

        this.state = {
            team: [],
            teamResul: [],
            logoImg: TeamLogo,
            flagImg: NationalityFlag,
            flagsImg: FlagImageList,
            isLoading: true,
        }

    }

    componentDidMount() {
        this.getAllData();
    }

    getAllData() {
        teamID = this.props.match.params.teamID
        var firstCall = $.ajax(`http://ergast.com/api/f1/2013/constructors/${teamID}/constructorStandings.json`);
        var secondCall = $.ajax(`http://ergast.com/api/f1/2013/constructors/${teamID}/results.json`);
        $.when(firstCall, secondCall).done(function (data1, data2) {
            this.setState({
                team: data1[0].MRData.StandingsTable.StandingsLists[0].ConstructorStandings,
                teamResul: data2[0].MRData.RaceTable.Races,
                isLoading: false
            });

        }.bind(this));
    }

    render() {
        if (this.state.isLoading) {
            return <h3>It is loading...</h3>;
        }

        let constrLogoUrl = this.state.logoImg.filter(vozac => vozac.constructorId === this.state.team[0].Constructor.constructorId)
        let constructorCountryImgUrl = this.state.flagImg.filter(drzava => drzava.nationality === this.state.team[0].Constructor.nationality)

        return (
            <div className="row centralni">

                <div className="col-3 teamlevi no-gutters">
                    <div className="teamlogo">
                        <div>
                            <img src={constrLogoUrl[0].logoUrl} alt="Team logo" width="75" height="55" />
                        </div>
                        <div>&nbsp;
                        <img src={constructorCountryImgUrl[0].flagUrl} alt="flag-country_code" width="50 " height="25" />
                            <h4>{this.state.team[0].Constructor.name}</h4>

                        </div>
                    </div>
                    <div className="teaminfo">
                        <p>Country: {this.state.team[0].Constructor.nationality}</p>
                        <p>Position: {this.state.team[0].position}</p>
                        <p>Points: {this.state.team[0].points}</p>
                        <p>History: <a href={this.state.team[0].Constructor.url} target="_blank" rel="noopener noreferrer"> &nbsp;<i className="fa fa-external-link"></i></a></p>
                    </div>
                </div>
                <div className="col-9 teamdesni no-gutters">

                    <table>
                        <thead>
                            <tr><th colSpan="2">Formula 1 YEAR Results</th><th></th><th></th><th></th></tr>
                        </thead>
                        <tbody>
                            <tr><td>Round</td><td>Grand Prix</td><td>{this.state.teamResul[0].Results[0].Driver.familyName}</td><td>{this.state.teamResul[0].Results[1].Driver.familyName}</td><td>Points</td></tr>
                            {this.state.teamResul.map((teamResul, i) => {
                                return <TeamResul key={i} data={teamResul} team={this.state.team[0]} flagsImgProps={this.state.flagsImg} />
                            })}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }
}


class TeamResul extends React.Component {
    render() {
        let country = this.props.flagsImgProps.filter(country => country.raceName === this.props.data.raceName)[0]
        return (
            <tr><td>{this.props.data.round}</td>
                <td>
                    <img src={country.countryImgUrl} alt="flag-country_code" width="32" height="20" />&nbsp;
                    {this.props.data.raceName}
                </td>
                <td className={"mesto" + this.props.data.Results[0].position}>{this.props.data.Results[0].position}</td>
                <td className={"mesto" + this.props.data.Results[1].position}>{this.props.data.Results[1].position}</td>
                <td>{+this.props.data.Results[0].points + +this.props.data.Results[1].points}</td>
            </tr>
        );
    }
}

export default Teamlink;