import React from 'react';
import * as $ from 'jquery';
import {
    Link,
} from "react-router-dom";

class Races extends React.Component {
    constructor() {
        super();

        this.state = {
            races: []
        }
    }

    componentDidMount() {
        this.getRaces();
    }

    getRaces() {
        var url = 'http://ergast.com/api/f1/2013/results/1.json';
        $.get(url, (data) => {
            this.setState({ races: data.MRData.RaceTable.Races });
        })

    }
    render() {
        return (
            <div className="main">
                <div className="naslov">Race Calendar</div>
                <table className="tabela">
                    <thead className="theader">
                        <tr><th colSpan="2">Race Calendar - 2013</th><th></th><th></th><th></th></tr>
                        <tr className="zaglavlje"><th>Round</th><th>Grand Prix</th><th>Circuit</th><th>Date</th><th>Winner</th></tr>
                    </thead>
                    <tbody>
                        {this.state.races.map((races, i) => { return <Calendar key={i} data={races} /> })}

                    </tbody>
                </table>

            </div>
        );
    }
}


class Calendar extends React.Component {
    render() {
        console.log(this.props.data);
        return (
            <tr><td>{this.props.data.round}</td>
                <td><Link exact to="/GrandPrix">{this.props.data.raceName}</Link></td>
                <td>{this.props.data.Circuit.circuitName}</td>
                <td>{this.props.data.date}</td>
                <td>{this.props.data.Results[0].Driver.driverId}</td>
            </tr>
        );
    }
}
export default Races;
