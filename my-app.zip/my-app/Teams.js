import React from 'react';
import * as $ from 'jquery';
import { Link } from "react-router-dom";
import history from './history';
import TeamLogo from './TeamLogo.json';

class Teams extends React.Component {
    constructor() {
        super();

        this.state = {
            teams: [],
            logoTeam: TeamLogo
        }
    }

    componentDidMount() {
        this.getTeams();
    }

    getTeams() {
        var url = 'http://ergast.com/api/f1/2013/constructorStandings.json';
        $.get(url, (data) => {
            this.setState({ teams: data.MRData.StandingsTable.StandingsLists[0].ConstructorStandings });
        })
    }
    render() {
        return (
            <div className="main">
                <div className="naslov">Constructor Championship</div>
                <table className="tabela">
                    <thead className="theader">
                        <tr><th colSpan="2">Constructor Championship Standings - 2013</th><th></th><th></th></tr>
                    </thead>
                    <tbody>
                        {this.state.teams.map((teams, i) => { return <Constructors key={i} data={teams} logoImgProps={this.state.logoTeam} /> })}
                    </tbody>
                </table>

            </div>
        );
    }
}

class Constructors extends React.Component {
    render() {
        let logo = this.props.logoImgProps.filter(country => country.constructorId === this.props.data.Constructor.constructorId)[0]
        return (
            <tr><td>{this.props.data.position}</td>
                <td>
                    <img src={logo.logoUrl} alt="flag-country_code" width="80" /> &nbsp;
                    <Link onClick={() => history.push('/Teamlink/' + this.props.data.Constructor.constructorId)}>
                        {this.props.data.Constructor.name}</Link>
                </td>
                <td><a href={this.props.data.Constructor.url} target="_blank" rel="noopener noreferrer">Details <i className="fa fa-external-link"></i></a></td>
                <td>{this.props.data.points}</td>
            </tr>
        );

    }
}
export default Teams;