import React from 'react';
import * as $ from 'jquery';
import App from './App';
import TeamLogo from './TeamLogo.json';
import NationalityFlag from './NationalityFlag.json'

var raceID = "";

class GrandPrix extends React.Component {
    constructor() {
        super();
        this.state = {
            race: [],
            raceResul: [],
            flagImg: NationalityFlag,
            isLoading: true,
        }
    }

    componentDidMount() {
        this.getAllData();
    }

    getAllData() {
        raceID = this.props.match.params.raceID
        var firstCall = $.ajax(`http://ergast.com/api/f1/2013/${raceID}/qualifying.json`);
        var secondCall = $.ajax(`http://ergast.com/api/f1/2013/${raceID}/qualifying.json`);
        $.when(firstCall, secondCall).done(function (data1, data2) {
            this.setState({
                race: data1[0].MRData.RaceTable.Races,
                raceResul: data2[0].MRData.RaceTable.Races,
                isLoading: false
            });
        }.bind(this));
    }

    render() {
        if (this.state.isLoading) {
            return <h3>It is loading...</h3>;
       }

        let constructorCountryImgUrl = this.state.flagImg.filter(drzava => drzava.nationality === this.state.race[0].Constructor.nationality)

        return (
            <div className="row centralni">
                <div className="col-3 teamlevi no-gutters">
                    <div className="teamlogo">
                        <div>
                            <img src={constrLogoUrl[0].logoUrl} alt="Team logo" width="75" height="55" />
                        </div>
                        <div>&nbsp;
                        <img src={constructorCountryImgUrl[0].flagUrl} alt="flag-country_code" width="50 " height="25" />
                            <h4>{this.state.team[0].Constructor.name}</h4>
                        </div>
                    </div>
                    <div className="teaminfo">
                        <p>Country: {this.state.team[0].Constructor.nationality}</p>
                        <p>Position: {this.state.team[0].position}</p>
                        <p>Points: {this.state.team[0].points}</p>
                        <p>History: <a href={this.state.team[0].Constructor.url} target="_blank" rel="noopener noreferrer"> &nbsp;<i className="fa fa-external-link"></i></a></p>
                    </div>
                </div>
                <div className="col-9 teamdesni no-gutters">
                    <table>
                        <thead>
                            <tr><th colSpan="2">Formula 1 YEAR Results</th><th></th><th></th><th></th></tr>
                        </thead>
                        <tbody>
                            <tr><td>Round</td><td>Grand Prix</td><td>{this.state.raceResul[0].Results[0].Driver.familyName}</td><td>{this.state.raceResul[0].Results[1].Driver.familyName}</td><td>Points</td></tr>
                            {this.state.raceResul.map((raceResul, i) => {
                                return <RaceResul key={i} data={raceResul} team={this.state.team[0]} />
                            })}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }
}

class RaceResul extends React.Component {
    render() {
        return (
            <tr><td>{this.props.data.round}</td>
                <td>{this.props.data.raceName}</td>
                <td className={"mesto" + this.props.data.Results[0].position}>{this.props.data.Results[0].position}</td>
                <td className={"mesto" + this.props.data.Results[1].position}>{this.props.data.Results[1].position}</td>
                <td>{+this.props.data.Results[0].points + +this.props.data.Results[1].points}</td>
            </tr>
        );
    }
}

export default GrandPrix;